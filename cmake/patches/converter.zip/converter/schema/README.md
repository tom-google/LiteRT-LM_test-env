This directory contains schema related files and targets that are used by both
the TFL converter (tf/compiler/mlir/lite/) and the runtime (tf/lite/).