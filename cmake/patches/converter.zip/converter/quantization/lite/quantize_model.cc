/* Copyright 2019 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tflite/converter/quantization/lite/quantize_model.h"

#include <optional>
#include <string>
#include <unordered_set>

#include "absl/container/flat_hash_set.h"  // from @com_google_absl
#include "absl/log/log.h"  // from @com_google_absl
#include "absl/status/status.h"  // from @com_google_absl
#include "absl/strings/string_view.h"  // from @com_google_absl
#include "llvm/ADT/StringRef.h"
#include "llvm/ADT/Twine.h"
#include "llvm/Support/Debug.h"
#include "mlir/IR/BuiltinOps.h"  // from @llvm-project
#include "mlir/IR/Location.h"  // from @llvm-project
#include "mlir/IR/MLIRContext.h"  // from @llvm-project
#include "mlir/IR/OwningOpRef.h"  // from @llvm-project
#include "mlir/Pass/PassManager.h"  // from @llvm-project
#include "mlir/Support/LogicalResult.h"  // from @llvm-project
#include "tflite/converter/common/tfl_pass_config.h"
#include "tflite/converter/debug/debug.h"
#include "tflite/converter/debug/debug_options.pb.h"
#include "tflite/converter/flatbuffer_export.h"
#include "tflite/converter/flatbuffer_import.h"
#include "tflite/converter/ir/tfl_ops.h"
#include "tflite/converter/quantization/common/quantization_lib/quantization_config.h"
#include "tflite/converter/schema/schema_generated.h"
#include "tflite/converter/tf_tfl_passes.h"
#include "tflite/converter/transforms/passes.h"
#include "tflite/converter/utils/convert_type.h"
#include "tensorflow/compiler/mlir/tensorflow/utils/error_util.h"
#include "tensorflow/core/framework/types.pb.h"

namespace mlir {
namespace lite {

std::string TfLiteToMlir(const absl::string_view tflite_op_name) {
  llvm::StringRef op_name(tflite_op_name.data(), tflite_op_name.size());
  return llvm::Twine("tfl.", op_name.lower()).str();
}

// TODO(fengliuai): check the result for `fully_quantize` flag.
absl::Status QuantizeModel(
    const absl::string_view model_buffer, const tflite::TensorType &input_type,
    const tflite::TensorType &output_type,
    const tflite::TensorType &inference_type,
    const std::unordered_set<std::string> &operator_names,
    bool disable_per_channel, bool fully_quantize, std::string &output_buffer,
    bool verify_numeric, bool whole_model_verify, bool legacy_float_scale,
    const absl::flat_hash_set<std::string> &denylisted_ops,
    const absl::flat_hash_set<std::string> &denylisted_nodes,
    const bool enable_variable_quantization,
    bool disable_per_channel_for_dense_layers,
    const std::optional<const tensorflow::converter::DebugOptions>
        &debug_options) {
  // Translate TFLite names to mlir op names.
  absl::flat_hash_set<std::string> denylisted_mlir_op_names;
  for (const auto& entry : denylisted_ops) {
    denylisted_mlir_op_names.insert(TfLiteToMlir(entry));
  }

  DialectRegistry registry;
  registry.insert<mlir::TFL::TensorFlowLiteDialect>();
  MLIRContext context(registry);
  StatusScopedDiagnosticHandler statusHandler(&context,
                                              /*propagate=*/true);

  OwningOpRef<mlir::ModuleOp> module = tflite::FlatBufferToMlir(
      model_buffer, &context, UnknownLoc::get(&context));
  if (!module) {
    return absl::InternalError("Couldn't import flatbuffer to MLIR.");
  }

  // Apply quantization passes.
  PassManager pm((*module)->getName(), OpPassManager::Nesting::Implicit);
  if (debug_options.has_value()) {
    // Add debugging instrumentation
    tensorflow::InitPassManager(pm, debug_options.value());
  }
  TFL::QuantizationSpecs quant_specs;
  quant_specs.inference_type = tflite::TflTypeToTfType(inference_type);
  quant_specs.post_training_quantization = true;
  quant_specs.disable_per_channel = disable_per_channel;
  quant_specs.disable_per_channel_for_dense_layers =
      disable_per_channel_for_dense_layers;
  quant_specs.verify_numeric = verify_numeric;
  quant_specs.whole_model_verify = whole_model_verify;
  quant_specs.legacy_float_scale = legacy_float_scale;
  quant_specs.ops_blocklist = denylisted_mlir_op_names;
  quant_specs.nodes_blocklist = denylisted_nodes;
  quant_specs.enable_mlir_variable_quantization = enable_variable_quantization;

  llvm::dbgs() << "fully_quantize: " << fully_quantize
               << ", inference_type: " << quant_specs.inference_type
               << ", input_inference_type: "
               << tflite::EnumNameTensorType(input_type)
               << ", output_inference_type: "
               << tflite::EnumNameTensorType(output_type) << "\n";
  mlir::Builder mlir_builder(&context);
  mlir::Type input_mlir_type =
      tflite::ConvertElementType(input_type, mlir_builder);
  mlir::Type output_mlir_type =
      tflite::ConvertElementType(output_type, mlir_builder);

  if (fully_quantize) {
    input_mlir_type = tflite::ConvertElementType(inference_type, mlir_builder);
    output_mlir_type = input_mlir_type;
  }

  tensorflow::AddQuantizationPasses(mlir::TFL::PassConfig(quant_specs), pm);
  pm.addPass(TFL::CreateModifyIONodesPass(input_mlir_type, output_mlir_type));
  // If the first or final ops are not quantized, remove QDQ.
  pm.addPass(TFL::CreatePostQuantizeRemoveQDQPass());
  if (failed(pm.run(module.get()))) {
    const std::string err(statusHandler.ConsumeStatus().message());
    return absl::InternalError(err);
  }

  // Export the results.
  tflite::FlatbufferExportOptions options;
  options.converter_flags.set_force_select_tf_ops(false);
  options.converter_flags.set_enable_select_tf_ops(true);
  options.converter_flags.set_allow_custom_ops(true);
  if (!tflite::MlirToFlatBufferTranslateFunction(module.get(), options,
                                                 &output_buffer)) {
    return absl::InternalError("Failed to export MLIR to flatbuffer.");
  }
  return absl::OkStatus();
}

}  // namespace lite
}  // namespace mlir
